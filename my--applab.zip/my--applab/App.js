import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Provider as PaperProvider } from 'react-native-paper';
//import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
//import DrawerNavigator from './DrawerNavigation';
import SplashScreen from "./Screens/SplashScreen";
import Login from "./Screens/Login";
import Signup from "./Screens/Signup";
import HomeScreen from "./Screens/HomeScreen";
import BorrowScreen from "./Screens/BorrowScreen";
import SearchScreen from './Screens/SearchScreen';


const Stack = createNativeStackNavigator()

export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="SplashScreen" component={SplashScreen} />
          <Stack.Screen name="Login" component={Login} />
          <Stack.Screen name="Signup" component={Signup} />
          <Stack.Screen name="HomeScreen" component={HomeScreen} />
          <Stack.Screen name="BorrowScreen" component={BorrowScreen} />
          <Stack.Screen name="SearchScreen" component={SearchScreen} />
        </Stack.Navigator>
        </NavigationContainer>
    </PaperProvider>
  );  
}
