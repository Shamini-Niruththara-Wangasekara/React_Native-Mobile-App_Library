import React,  {Component} from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { Button, Card, DefaultTheme} from 'react-native-paper';
import { useTheme } from '@react-navigation/native';
import {View, Text, Image, TouchableOpacity, FlatList, SafeAreaView, Platform,  Dimensions, TextInput, } from 'react-native';
import Icon from "react-native-vector-icons";

// Default screen
const HomeScreen = ({ navigation }) =>{
  const categories = ['Computer' ,'Maths', 'Science', 'Art', 'Commerce'];
  const [catergoryIndex, setCategoryIndex] = React.useState(0)

  const CategoryList = ()=>{
      return (
      <View style={styles.catcon}>
        {categories.map((item, index) =>(
          <Text  key={index} style={[styles.cattext, catergoryIndex ==index && styles.cattextSelected]}>
            {item}</Text>

        ))}
        
      </View>
      );
    };
  
    return (
        <ScrollView style={styles.screen} centerContent contentContainerStyle={styles.scroll}>
        <View style={styles.header}>
        <Text style={{ fontSize: 25, fontWeight: 'bold', color: '#0f4232', marginTop:20 }}>
          Welcome to Bookstore.. 
        </Text></View>
        <View style={styles.footer}>
        <View style={{marinTop:45, flexDirection:"row"}}>
          <View style={styles.searchcon}>
            <TextInput placeholder='search books' style={styles. input}/>
          </View>

        </View>
        <CategoryList />
        <View style={{marinTop:39, flexDirection:"row"}}>
          <View style={styles.Textcont}>
          <Text style={styles.Textcont}>PROGRAMMING</Text>
          </View>
          </View>
          <View >
            <Image 
                source={require('../assets/flat.jpg')}
                style={styles.logo}
                resizeMode='stretch' />
                <Text onPress={() => navigation.push('SearchScreen')}>+ find more</Text>
        </View>
            
          <View style={{marinTop:39, flexDirection:"row"}}>
          <View style={styles.Textcont}>
            <Text style={styles.Textcont}>WEB DESIGNING</Text>
          </View>
          </View>
          <View >
            <Image 
                source={require('../assets/flat3.jpg')}
                style={styles.logo}
                resizeMode='stretch' />
                <Text onPress={() => navigation.push('SearchScreen')}>+ find more</Text>
        </View>
          <View style={{marinTop:39, flexDirection:"row"}}>
          <View style={styles.Textcont}>
          <Text style={styles.Textcont}>NETWORKING</Text>
          </View>
          </View> 
          <View >
            <Image
                source={require('../assets/flat2.jpg')}
                style={styles.logo}
                resizeMode='stretch' />
                <Text onPress={() => navigation.push('SearchScreen')}>+ find more</Text>
        </View> 
          <View style={{marinTop:39, flexDirection:"row"}}>
          <View style={styles.Textcont}>
          <Text style={styles.Textcont}>MOBILE APPDEVELOPMENT</Text>
          </View>
          </View>
          <View >
            <Image
                source={require('../assets/flat1.jpg')}
                style={styles.logo}
                resizeMode='stretch' />
                <Text onPress={() => navigation.push('SearchScreen')}>+ find more</Text>
        </View> 
        </View>         
      </ScrollView>
      ); 
    };
export default HomeScreen;
        //<ScrollView style={styles.scrollView}>
        //  <Card style={styles.card}>
           //<Card.Title title="Navigate to" />
            //<Card.Content>
             // <Button mode="contained" onPress={() => navigation.navigate('Book')}>
               
             // </Button>
             // <Button style={{marginTop:15}} mode="contained" onPress={() => navigation.navigate('Borrow')}>
              
            //  </Button>
            //</Card.Content>
          //</Card>
       // </ScrollView> 
      // <View style={styles.container}>   
      //<FlatList style={styles.ftl}
   // data={[
             //  {key: 'PROGRAMMING'},
              // {key: ' '},
              // {key: ' '},
             //  {key: ' '},
              
               
           //]}
           //creating render item object
           //renderItem={({item})=><Text style={styles.item}>{item.key}</Text>}
      // />
      //<Button onPress={() => navigation.push('BookList')}> </Button>
  // </View> 



  // Styles
  const styles = StyleSheet.create({
   
    card: {
      width: '90%',
      marginLeft: 'auto',
      marginRight: 'auto'
    },
    
    title: {
      fontSize: 50,
      lineHeight: 60,
      fontWeight: '700',
     
    },
    subTitle: {
      fontSize: 17,
      fontWeight: '500',
      
    },
    searchcon:{
      height:50,
      backgroundColor:"#bfc7bb",
      borderRadius:10,
      flex:1,
      flexDirection:'row',
      alignItems:'center',

    },
    
    input:{
      fontSize:20,
      fontWeight:'bold',
      color:'#fff',
      marginLeft:20,
      alignContent:'center',
       
    },

    Textcont:{
      fontSize:20,
      fontWeight:'bold',
      color:'#009287',
      marginLeft:20,
      alignContent:'center',
       
    },

    catcon:{
      flexDirection:'row',
      marginTop:30,
      marginBottom:20,
      justifyContent:'space-between'
    },

    cattext:{
      color:'black', fontWeight:'bold', fontSize:17, alignItems:'center'},
    
    cattextSelected:{
      color:'#044a12',
      paddingBottom:1,
      borderBottomWidth:2,
      borderColor:'#044a12',
    },
    screen:{
      paddingHorizontal:10

    },
    logo:{
      height:120,
      width:80,
      alignContent:'center',
      alignSelf:'baseline',
      paddingTop:-10,
      paddingBottom:-10,
      marginTop:5
  },
 
    footer:{
      flex:1,
      backgroundColor:'#fff',
      borderTopLeftRadius:30,
      borderTopRightRadius:30,
      paddingHorizontal:30,
      paddingVertical:30,
      paddingTop:20,
      paddingBottom:20 
  },
    header:{
      flex:1,
      justifyContent:"flex-start",
      paddingHorizontal: 10,
      paddingBottom:3,
  
  },
    Button:{
     color:'black',
}


});
      
      
    
 

