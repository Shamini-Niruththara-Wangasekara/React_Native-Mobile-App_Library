import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, Button} from 'react-native';


function SplashScreen ({ navigation }){
    return(
        <><View style={{ justifyContent: 'center', alignItems: 'center' }}>
            <Text style={styles.text_sn}>SN Book Store</Text>
        </View><View style={styles.container}>
                <View style={styles.header}>
                    <Image
                        source={require('../assets/applogo.jpg')}
                        style={styles.logo}
                        resizeMode='stretch' />
                </View>
                <View style={styles.footer}>
                    <Text style={styles.text_sn1}>Stay Connected with Books..</Text>
                    <Text style={styles.text_sam}>Signin with the account</Text>
                    <TouchableOpacity >
                        <Text style={styles.But} onPress={() => navigation.navigate('Login')} title='Get started'>Get Started  </Text>
                    </TouchableOpacity>
                </View>
            </View></>
    );
};
export default SplashScreen;

const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#017a54',
    },
    Button:{
        margintop:50,
    },
    header:{
        flex:1,
        justifyContent:"flex-start",
        paddingHorizontal: 20,
        paddingBottom:250
    },
    footer:{
        flex:3,
        backgroundColor:'#fff',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:30,
        paddingVertical:30,
        paddingTop:20,
        paddingBottom:20
    },
    logo:{
        height:150,
        width:150,
        alignContent:'center',
        alignSelf:'center',
        paddingTop:30,
        paddingBottom:30,
        marginTop:70
    },
    text_sn:{
        fontSize:35,
        fontWeight:'bold',
        color:'#0f4232'
    },

    text_sn1:{
        fontSize:25,
        fontWeight:'bold',
        color:'#0f4232'
    },

    text_sam:{
        fontSize:15,
        fontWeight:'bold',
        color:'##05120e',
        marginTop:15
    },
    But:{
        
        backgroundColor:'#009287',
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
        borderTopRightRadius:30,
        height:50,
        color:'#fff',
        fontSize:20,
        textAlign:'center',
        width:-300,
        marginTop:20

    }


});