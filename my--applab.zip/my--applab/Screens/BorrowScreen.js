import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Card } from 'react-native-paper';
import { DefaultTheme } from 'react-native-paper';
import { Text, TouchableOpacity, Image, Button} from 'react-native';

    function BorrowScreen ({ navigation }){
      return(
          <><View style={{ justifyContent: 'center', alignItems: 'center' }}>
              <Text style={styles.text_sn}>Book Details</Text>
          </View><View style={styles.container}>
                  <View style={styles.header}>
                      <Image
                          source={require('../assets/flat.jpg')}
                          style={styles.logo}
                          resizeMode='stretch' />
                  </View>
                  <View style={styles.footer}>
                      <Text style={styles.text_sam}>Author:    Robert Cecil</Text>
                      <Text style={styles.text_sam}>Description:   A handbook of Agile Software Craftmanship 1st Edition; core concept, presents the principles, patterns, and practices of writing clean code.</Text>
                      <Text style={styles.text_sam}>Price:   Rs. 3950.00</Text>
                      <TouchableOpacity >
                          <Text style={styles.But} onPress={() => navigation.navigate('payment')}>Buy Now</Text>
                      </TouchableOpacity>
                  </View>
              </View></>
      );
  };
  export default BorrowScreen;
 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: DefaultTheme.colors.background,
    alignItems: 'center',
    paddingTop: 10
  },
  card: {
    width: '90%'
  },
  container:{
    flex: 1,
    backgroundColor:'#017a54',
},
Button:{
    margintop:50,
},
header:{
    flex:1,
    justifyContent:"flex-start",
    paddingHorizontal: 20,
    paddingBottom:250
},
footer:{
    flex:3,
    backgroundColor:'#fff',
    borderTopLeftRadius:30,
    borderTopRightRadius:30,
    paddingHorizontal:30,
    paddingVertical:30,
    paddingTop:20,
    paddingBottom:20
},
logo:{
    height:150,
    width:120,
    alignContent:'center',
    alignSelf:'center',
    paddingTop:30,
    paddingBottom:30,
    marginTop:70
},
text_sn:{
    fontSize:35,
    fontWeight:'bold',
    color:'#0f4232',
    marginTop:15
},
text_sam:{
    fontSize:15,
    fontWeight:'bold',
    color:'##05120e',
    marginTop:15
},
But:{
    
    backgroundColor:'#009287',
    borderTopLeftRadius:30,
    borderBottomLeftRadius:30,
    borderBottomRightRadius:30,
    borderTopRightRadius:30,
    height:50,
    color:'#fff',
    fontSize:20,
    textAlign:'center',
    width:-300,
    marginTop:20

}
});

