import React from 'react';
import { View,Button,Text, TextInput, ImageBackground,StyleSheet } from 'react-native';

function Signup ({ navigation }){
const [signupState, setSignupState] = React.useState({
email: '',
password: '',
confirmPassword: '',
error: '',
loading: false,
});
const handleSignup = () =>{

if(signupState.email !== '' && signupState.password !== '' && signupState.confirmPassword !== '' && signupState.district !== '' && signupState.city !== ''){
if(signupState.password !== signupState.confirmPassword){
    alert('Password and Confirm Password do not match');

}else {
    setSignupState({...signupState, error: '', loading: true});
    navigation.navigate('HomeScreen');
    
}
}
alert('Please fill all the fields');
}
return(
    <View style={styles.container}>
    <View style={styles.header}>
    <Text style={styles.text_sn}>Signup</Text> 
    </View>
    <View style={styles.footer}>
    <Text style={styles.text_sam}>Email</Text> 
    <TextInput placeholder='Type your Email here' onChangeText={(text)=>setSignupState({...signupState, email: text})}></TextInput>
    <Text style={styles.text_sam}>Password</Text> 
    <TextInput placeholder='Password' onChangeText={(text)=>setSignupState({...signupState, password:text})}></TextInput>
    <Text style={styles.text_sam}>Confirm Password</Text>
    <TextInput placeholder='Confirm Password' onChangeText={(text)=>setSignupState({...signupState, confirmPassword:text})}></TextInput>
    <Text style={styles.But} onPress={handleSignup} title='Signup'>Signin</Text>
    </View>
</View>

) 
} 
export default Signup;
const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#009287',
        justifyContent:'center',
        alignItems:'center'
    },
    Button:{
        margintop:50,
    },
    header:{
        flex:1,
        justifyContent:"flex-end",
        paddingHorizontal: 20,
        paddingBottom:50
    },
    footer:{
        flex:3,
        backgroundColor:'#fff',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:115,
        paddingVertical:40,
    },
    text_sn:{
        fontSize:35,
        fontWeight:'bold',
        color:'#0f4232',
        maxWidth:100
        
    },
    text_sam:{
        fontSize:20,
        fontWeight:'bold',
        color:'##05120e',
        marginTop:15
    },
    text_sm1:{
        fontSize:15,
        width:190,
        marginTop:15,
    },
    But:{
        
        backgroundColor:'#009287',
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
        borderTopRightRadius:30,
        height:50,
        color:'#fff',
        fontSize:20,
        textAlign:'center',
        width:-300,
        marginTop:20

    }
});