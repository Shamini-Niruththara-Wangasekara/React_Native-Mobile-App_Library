import React from 'react';
import {View, Text, TouchableOpacity, Button, TextInput, StyleSheet, Image} from 'react-native';

 const Login = ({ navigation }) =>{ 

     const [email, setEmail] = React.useState(''); 
     const [password, setPassword] = React.useState(''); 

     const handleLogin = () =>
     { if(email !== '' && password !== ''){ 
         navigation.navigate('HomeScreen');
    }   else{ alert('Please fill all the fields'); 
     } 
} 
return( 
    <View style={styles.container}>
    <View style={styles.header}>
    <Text style={styles.text_sn}>Login</Text> 
    </View>
    <View style={styles.footer}>
    <Text style={styles.text_sam}>Email</Text>
        <TextInput placeholder='Type your Email here' onChangeText={(text)=>setEmail(text)}>
        </TextInput>
    <Text style={styles.text_sam}>Password</Text>      
        <TextInput placeholder='Password' onChangeText={(text)=>setPassword(text)}>
        </TextInput> 
    <Text style={styles.But} onPress={handleLogin} title='Login'>Login</Text> 
    <Text style={styles.text_sm1}> Dont you have an Account. Signup</Text>
    <Text style={styles.But}onPress={()=> navigation.navigate('Signup')} title='Register'>SignUp</Text> 
    <Text style={styles.But} onPress={()=> navigation.navigate('rest')} title='Reset password'>Reset Password</Text> 
    </View> 
    </View >
) 
} 
export default Login;


const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#009287',
        justifyContent:'center',
        alignItems:'center'
    },
    Button:{
        margintop:50,
    },
    header:{
        flex:1,
        justifyContent:"flex-end",
        paddingHorizontal: 20,
        paddingBottom:50
    },
    footer:{
        flex:3,
        backgroundColor:'#fff',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:90,
        paddingVertical:50,
    },
    text_sn:{
        fontSize:35,
        fontWeight:'bold',
        color:'#0f4232',
        maxWidth:100
        
    },
    text_sam:{
        fontSize:20,
        fontWeight:'bold',
        color:'##05120e',
        marginTop:15
    },
    text_sm1:{
        fontSize:15,
        width:190,
        marginTop:15,
    },
    But:{
        
        backgroundColor:'#009287',
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
        borderTopRightRadius:30,
        height:50,
        color:'#fff',
        fontSize:20,
        textAlign:'center',
        width:-300,
        marginTop:10,
        justifyContent:'center'
    }


})