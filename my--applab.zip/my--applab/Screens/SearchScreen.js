import React  from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { Button, Card, DefaultTheme} from 'react-native-paper';
import { useTheme } from '@react-navigation/native';
import {View, Text, Image, TouchableOpacity, FlatList, SafeAreaView, Platform,  Dimensions, TextInput, } from 'react-native';
import Icon from "react-native-vector-icons";

function SearchScreen({ navigation }) {
  const [text7, onChangeText7] = React.useState(null);
  const [text8, onChangeText8] = React.useState(null);
  const [text9, onChangeText9] = React.useState(null);
  return (
    <View style={styles.container}>
        <Text style={{ fontSize: 25, fontWeight: 'bold', color: '#0f4232', marginTop:20 }}>Advanced Search </Text> 
    <SafeAreaView>
      <Text style={styles.textB}>Search by Title</Text>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText7}
        value={text7}
        placeholder="Enter title"
        keyboardType="default"
      />
      
      <Text style={styles.textB}>Search by Author</Text>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText8}
        value={text8}
        placeholder="Enter author"
        keyboardType="default"
      />
      <Text style={styles.textB}>Search by Category</Text>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText9}
        value={text9}
        placeholder="Enter category"
        keyboardType="default"
      />
      <Text style={styles.But} onPress={()=> navigation.navigate('BorrowScreen')} >Search</Text> 
    </SafeAreaView>
    </View>
    
    );
  }

  const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor:'#fff',
        paddingHorizontal:10  
    },

    text:{
      color: 'white',
      fontWeight: 'bold',
      fontSize: 40
    },
    textA:{
      fontSize: 40,
      margin:20
    },
    
    input: {
      height: 40,
      margin: 12,
      borderWidth: 1,
      padding: 10
    },

    textB:{
      fontSize: 20,
      fontWeight: 'bold',
      paddingLeft: 15,
      paddingTop: 10,
      color: '#009287'
    },
    footer:{
        flex:1,
        backgroundColor:'green',
        borderTopLeftRadius:30,
        borderTopRightRadius:30,
        paddingHorizontal:90,
        paddingVertical:50,
    },
    But:{
        backgroundColor:'#009287',
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:30,
        borderTopRightRadius:30,
        height:50,
        color:'#fff',
        fontSize:20,
        textAlign:'center',
        width:100,
        marginTop:10,
        justifyContent:'center',
        alignSelf:'center'
    }

  });

  export default SearchScreen;